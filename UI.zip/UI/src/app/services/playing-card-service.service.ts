import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlayingCardServiceService {

  //private url: string = "http://localhost:64283/api/SortCardDeck";
  private url: string = "https://playingcardapi20220320130653.azurewebsites.net/api/SortCardDeck";

  constructor(private client: HttpClient) {
  }

  public SortCardDeck(reqData: any) {
    return this.client.post(this.url, reqData);
  }

}