import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { PlayingCardServiceService } from '../services/playing-card-service.service';

@Component({
  selector: 'app-card-deck',
  templateUrl: './card-deck.component.html',
  styleUrls: ['./card-deck.component.css']
})

export class CardDeckComponent implements OnInit {
  inputArr: string[] = [];
  sortedArr: any = [];
  alertMessage: any = {};

  constructor(private playingCardServiceService: PlayingCardServiceService, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
  }

  AddCardToList(cardOperation: string) {
    cardOperation = cardOperation.toUpperCase();
    if (typeof cardOperation != 'undefined' && cardOperation) {
      if (!this.inputArr.includes(cardOperation)) {
        this.inputArr.push(cardOperation);
        this.alertMessage = { type: 'success', text: 'This card added successfully.' };
      }
      else {
        this.alertMessage = { type: 'error', text: 'This card already exists.' };
      }
    }
    else {
      this.alertMessage = { type: 'error', text: 'Please enter a valid value.' };
    }
  }

  ClearAll() {
    this.spinner.show();

    setTimeout(() => {
      this.inputArr = [];
      this.sortedArr=[];
      this.alertMessage = { type: 'success', text: 'All cards deleted successfully.' };
      this.spinner.hide();
    }, 1000);
  }

  SortCard() {
    this.spinner.show();

    setTimeout(() => {
      this.playingCardServiceService.SortCardDeck(this.inputArr).subscribe((response) => {
        this.sortedArr = response;
        this.alertMessage = { type: 'success', text: 'Input cards sorted successfully.' };
        this.spinner.hide();
      },
        (error) => {
          this.alertMessage = { type: 'error', text: 'Some Error occoured' };
          this.spinner.hide();
        }
      );
      this.spinner.hide();
    }, 3000);
  }
}