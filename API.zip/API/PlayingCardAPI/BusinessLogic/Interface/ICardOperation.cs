﻿using System.Collections.Generic;
using Entities;

namespace BusinessLogic.Interface
{
    /// <summary>
    /// Interface ICardOperation
    /// </summary>
    public interface ICardOperation
    {
        /// <summary>
        /// Sort Cards Business logic
        /// </summary>
        /// <param name="cards">Input crads</param>
        /// <returns>response</returns>
        List<string> ShortCard(List<PlayingCard> cards);
    }
}
