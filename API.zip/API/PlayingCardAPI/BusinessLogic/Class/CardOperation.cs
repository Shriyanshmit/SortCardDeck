﻿using System;
using System.Collections.Generic;
using System.Linq;
using BusinessLogic.Interface;
using Entities;

namespace BusinessLogic.Class
{
    public class CardOperation : ICardOperation
    {
        public List<string> ShortCard(List<PlayingCard> cards)
        {
            try
            {   
                cards.Sort(new CustomCardSort());
                return cards.Select(s => s.Value).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}