﻿using System;
using System.Collections.Generic;
using System.Linq;
using BusinessLogic.Interface;
using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PlayingCardAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SortCardDeckController : ControllerBase
    {
        private readonly ICardOperation cardOperation;

        /// <summary>
        /// Constructor of SortCardDeck Controller
        /// </summary>
        /// <param name="cardOperation">Dependency ICardOperation cardOperation</param>
        public SortCardDeckController(ICardOperation cardOperation)
        {
            this.cardOperation = cardOperation;
        }

        /// <summary>
        /// Get card by sorted order
        /// </summary>
        /// <param name="cards">Input cards</param>
        /// <returns>return sorted card or validation message</returns>
        [HttpPost]
        public ActionResult<List<string>> Post(List<String> cards)
        {
            try
            {
                // Check null value or count
                if (cards == null || cards.Count == 0)
                    return BadRequest();

                // Format card to custom class type
                List<PlayingCard> listOfCards = new List<PlayingCard>();
                foreach (var card in cards)
                {
                    listOfCards.Add(new PlayingCard(card));
                }

                // Invalid card input
                if (listOfCards.Count(s => s.IsValid == false) > 0)
                {
                    return BadRequest("Invalid card input.");
                }

                return cardOperation.ShortCard(listOfCards);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error occoured at the time of sorting the cards.");
            }
        }
    }
}