﻿namespace Entities
{
    /// <summary>
    /// Enum for card kind
    /// </summary>
    public enum Kind
    {
        Take4,
        Take2,
        Swap,
        Pause,
        Reverse,

        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King,
        Ace,
    }

    /// <summary>
    /// Enum for card Type
    /// </summary>
    public enum Suit
    {
        T,
        D,
        S,
        C,
        H
    }

    /// <summary>
    /// Card class
    /// </summary>
    public class PlayingCard
    {
        #region "Properties"

        public bool IsValid { get; set; } = true;
        public Kind Kind { get; set; }
        public Suit Suit { get; set; }
        public string Value { get; set; }

        #endregion

        #region "Constructor"
       
        public PlayingCard(string inputvalue)
        {
            Value = inputvalue;
            string kind;
            string suit;

            if (inputvalue.Length == 2)
            {
                kind = inputvalue.Substring(0, 1);
                suit = inputvalue.Substring(1, 1);
            }
            else
            {
                kind = inputvalue.Substring(0, 2);
                suit = inputvalue.Substring(2, 1);
            }

            switch (suit)
            {
                case "T":
                    Suit = Suit.T;

                    switch (kind)
                    {
                        case "4":
                            Kind = Kind.Take4;
                            break;
                        case "2":
                            Kind = Kind.Take2;
                            break;
                        case "S":
                            Kind = Kind.Swap;
                            break;
                        case "P":
                            Kind = Kind.Pause;
                            break;
                        case "R":
                            Kind = Kind.Reverse;
                            break;
                        default:
                            IsValid = false;
                            break;
                    }
                    break;

                case "D":
                    Suit = Suit.D;
                    break;

                case "S":
                    Suit = Suit.S;
                    break;

                case "C":
                    Suit = Suit.C;
                    break;

                case "H":
                    Suit = Suit.H;
                    break;

                default:
                    IsValid = false;
                    break;
            }

            if (Suit != Suit.T)
            {
                switch (kind)
                {
                    case "2":
                        Kind = Kind.Two;
                        break;

                    case "3":
                        Kind = Kind.Three;
                        break;

                    case "4":
                        Kind = Kind.Four;
                        break;

                    case "5":
                        Kind = Kind.Five;
                        break;

                    case "6":
                        Kind = Kind.Six;
                        break;

                    case "7":
                        Kind = Kind.Seven;
                        break;

                    case "8":
                        Kind = Kind.Eight;
                        break;

                    case "9":
                        Kind = Kind.Nine;
                        break;

                    case "10":
                        Kind = Kind.Ten;
                        break;

                    case "J":
                        Kind = Kind.Jack;
                        break;

                    case "Q":
                        Kind = Kind.Queen;
                        break;

                    case "K":
                        Kind = Kind.King;
                        break;

                    case "A":
                        Kind = Kind.Ace;
                        break;

                    default:
                        IsValid = false;
                        break;
                }
            }
        }

        #endregion
    }
}