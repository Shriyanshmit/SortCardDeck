﻿using System.Collections.Generic;

namespace Entities
{
    /// <summary>
    /// Custom Card sort class
    /// </summary>
    public class CustomCardSort : IComparer<PlayingCard>
    {
        /// <summary>
        /// Compare 2 objects
        /// </summary>
        /// <param name="x">Input x</param>
        /// <param name="y">Input y</param>
        /// <returns>Compare by Suit and Kind of card</returns>
        public int Compare(PlayingCard x, PlayingCard y)
        {
            if (x.Suit != y.Suit)
            {
                return x.Suit.CompareTo(y.Suit);
            }

            return x.Kind.CompareTo(y.Kind);
        }
    }
}
