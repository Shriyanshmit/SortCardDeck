using BusinessLogic.Class;
using BusinessLogic.Interface;
using PlayingCardAPI.Controllers;
using System;
using System.Collections.Generic;
using Xunit;

namespace WEB_APT_Tests
{
    public class SortCardDeckControllerTest
    {
        private readonly SortCardDeckController _controller;
        private readonly ICardOperation _service;

        public SortCardDeckControllerTest()
        {
            _service = new CardOperation();
            _controller = new SortCardDeckController(_service);
        }

        [Fact]
        public void TestCardDeck()
        {
            // Arrange
            var inputCards = new List<string>()
            {
                "3C", "JS", "2D", "PT", "10H", "KH", "8S", "4T", "AC", "4H", "RT"
            };

            // Act
            var response = _controller.Post(inputCards);
            var expected = new List<string>() { "4T",
                                                "PT",
                                                "RT",
                                                "2D",
                                                "8S",
                                                "JS",
                                                "3C",
                                                "AC",
                                                "4H",
                                                "10H",
                                                "KH"};
                       
            // Assert
            Assert.Equal(response.Value, expected);
        }
    }
}
